"""策略注册表。"""
from .trend import TrendFollowingStrategy
from .mean_reversion import MeanReversionStrategy
from .multi_factor import MultiFactorStrategy

STRATEGY_MAP = {
    "trend": TrendFollowingStrategy,
    "mean_reversion": MeanReversionStrategy,
    "multi_factor": MultiFactorStrategy,
}


def get_strategy(name: str):
    key = name.strip().lower().replace("-", "_")
    if key not in STRATEGY_MAP:
        raise ValueError(f"未知策略: {name}，可选: {list(STRATEGY_MAP)}")
    return STRATEGY_MAP[key]()
