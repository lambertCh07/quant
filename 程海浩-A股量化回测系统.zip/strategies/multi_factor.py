"""多因子打分：动量 + 波动 + 均线偏离 + 可选舆情。"""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from .base import BaseStrategy


class MultiFactorStrategy(BaseStrategy):
    name = "multi_factor"
    default_params = {
        "mom_window": 20,
        "vol_window": 20,
        "ma_window": 60,
        "buy_threshold": 0.55,
        "sell_threshold": 0.45,
        "w_mom": 0.35,
        "w_vol": 0.25,
        "w_ma": 0.25,
        "w_sent": 0.15,
        "use_sentiment": 1,
    }

    def generate_signals(
        self,
        df: pd.DataFrame,
        params: Dict[str, Any] | None = None,
        sentiment: Optional[pd.Series] = None,
    ) -> pd.Series:
        p = self.resolve_params(params)
        close = df["close"].astype(float)

        mom_w = int(p["mom_window"])
        vol_w = int(p["vol_window"])
        ma_w = int(p["ma_window"])

        # 动量：过去 N 日收益率，越高越好
        mom = close.pct_change(mom_w)
        # 波动：过去 N 日收益标准差，越低越好
        vol = close.pct_change().rolling(vol_w).std()
        # 均线偏离：(close - MA) / MA
        ma = close.rolling(ma_w, min_periods=ma_w).mean()
        ma_dev = (close - ma) / ma

        def _rank01(s: pd.Series, ascending: bool = True) -> pd.Series:
            return s.rank(pct=True, ascending=ascending)

        f_mom = _rank01(mom, ascending=True)
        f_vol = _rank01(vol, ascending=False)  # 低波动高分
        f_ma = _rank01(ma_dev, ascending=True)

        use_sent = int(p.get("use_sentiment", 1)) == 1
        w_mom, w_vol, w_ma, w_sent = (
            float(p["w_mom"]),
            float(p["w_vol"]),
            float(p["w_ma"]),
            float(p["w_sent"]),
        )

        if use_sent and sentiment is not None and len(sentiment) > 0:
            sent = sentiment.reindex(df.index).ffill().fillna(0.5)
            f_sent = _rank01(sent, ascending=True)
            total_w = w_mom + w_vol + w_ma + w_sent
            score = (w_mom * f_mom + w_vol * f_vol + w_ma * f_ma + w_sent * f_sent) / total_w
        else:
            total_w = w_mom + w_vol + w_ma
            score = (w_mom * f_mom + w_vol * f_vol + w_ma * f_ma) / total_w

        buy_th = float(p["buy_threshold"])
        sell_th = float(p["sell_threshold"])

        signal = pd.Series(0, index=df.index, dtype=int)
        position = 0
        for i in range(len(df)):
            sc = score.iloc[i]
            if np.isnan(sc):
                signal.iloc[i] = 0
                continue
            if sc >= buy_th:
                position = 1
            elif sc <= sell_th:
                position = 0
            signal.iloc[i] = position
        return signal
