"""趋势跟踪：双均线交叉。"""
from __future__ import annotations

from typing import Any, Dict

import pandas as pd

from .base import BaseStrategy


class TrendFollowingStrategy(BaseStrategy):
    name = "trend"
    default_params = {"short_window": 5, "long_window": 20}

    def generate_signals(self, df: pd.DataFrame, params: Dict[str, Any] | None = None) -> pd.Series:
        p = self.resolve_params(params)
        short_w = int(p["short_window"])
        long_w = int(p["long_window"])
        if short_w >= long_w:
            raise ValueError("short_window 必须小于 long_window")

        close = df["close"].astype(float)
        ma_s = close.rolling(short_w, min_periods=short_w).mean()
        ma_l = close.rolling(long_w, min_periods=long_w).mean()

        signal = pd.Series(0, index=df.index, dtype=int)
        signal[ma_s > ma_l] = 1
        signal[ma_s <= ma_l] = 0
        signal = signal.where(ma_l.notna(), 0).astype(int)
        return signal
