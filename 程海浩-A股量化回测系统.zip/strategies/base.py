"""策略基类。"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict

import pandas as pd


class BaseStrategy(ABC):
    name: str = "base"
    default_params: Dict[str, Any] = {}

    def resolve_params(self, params: Dict[str, Any] | None = None) -> Dict[str, Any]:
        merged = dict(self.default_params)
        if params:
            merged.update(params)
        return merged

    @abstractmethod
    def generate_signals(self, df: pd.DataFrame, params: Dict[str, Any] | None = None) -> pd.Series:
        """
        基于当日收盘可得信息生成信号。
        返回 Series，索引与 df 对齐，取值：
          1  = 买入/持有多头目标
          0  = 空仓
         -1  = 卖出（与 0 在组合层等价为空仓，保留语义）
        """
        raise NotImplementedError
