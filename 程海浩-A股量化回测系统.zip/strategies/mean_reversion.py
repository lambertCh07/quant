"""均值回复：布林带。"""
from __future__ import annotations

from typing import Any, Dict

import pandas as pd

from .base import BaseStrategy


class MeanReversionStrategy(BaseStrategy):
    name = "mean_reversion"
    default_params = {"window": 20, "num_std": 2.0}

    def generate_signals(self, df: pd.DataFrame, params: Dict[str, Any] | None = None) -> pd.Series:
        p = self.resolve_params(params)
        window = int(p["window"])
        num_std = float(p["num_std"])

        close = df["close"].astype(float)
        mid = close.rolling(window, min_periods=window).mean()
        std = close.rolling(window, min_periods=window).std()
        upper = mid + num_std * std
        lower = mid - num_std * std

        # 状态机：跌破下轨买入，涨破上轨卖出，中间保持
        signal = pd.Series(0, index=df.index, dtype=int)
        position = 0
        for i in range(len(df)):
            if pd.isna(lower.iloc[i]) or pd.isna(upper.iloc[i]):
                signal.iloc[i] = 0
                continue
            price = close.iloc[i]
            if price < lower.iloc[i]:
                position = 1
            elif price > upper.iloc[i]:
                position = 0
            signal.iloc[i] = position
        return signal
