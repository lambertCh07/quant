"""拉取十只股票 + 沪深300 前复权日线，并生成舆情日度 CSV。

主源：BaoStock（稳定）；备用：AkShare。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config


def _normalize(df: pd.DataFrame) -> pd.DataFrame:
    colmap = {}
    for c in df.columns:
        cs = str(c)
        cl = cs.lower()
        if "日期" in cs or cl == "date":
            colmap[c] = "date"
        elif "开盘" in cs or cl == "open":
            colmap[c] = "open"
        elif "最高" in cs or cl == "high":
            colmap[c] = "high"
        elif "最低" in cs or cl == "low":
            colmap[c] = "low"
        elif "收盘" in cs or cl == "close":
            colmap[c] = "close"
        elif "成交量" in cs or cl == "volume":
            colmap[c] = "volume"
    out = df.rename(columns=colmap)
    keep = [c for c in ["date", "open", "high", "low", "close", "volume"] if c in out.columns]
    out = out[keep].copy()
    out["date"] = pd.to_datetime(out["date"])
    for c in ["open", "high", "low", "close", "volume"]:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    out = out.dropna(subset=["date", "close"])
    out = out.sort_values("date").drop_duplicates("date")
    start = pd.Timestamp(config.DATA_START)
    end = pd.Timestamp(config.DATA_END)
    out = out[(out["date"] >= start) & (out["date"] <= end)]
    return out.reset_index(drop=True)


def _bs_code(symbol: str, is_index: bool = False) -> str:
    if is_index:
        return f"sh.{symbol}"
    if symbol.startswith(("5", "6", "9")):
        return f"sh.{symbol}"
    return f"sz.{symbol}"


def fetch_baostock(symbol: str, is_index: bool = False) -> pd.DataFrame:
    import baostock as bs

    lg = bs.login()
    if lg.error_code != "0":
        raise RuntimeError(f"baostock login failed: {lg.error_msg}")
    try:
        code = _bs_code(symbol, is_index=is_index)
        rs = bs.query_history_k_data_plus(
            code,
            "date,open,high,low,close,volume",
            start_date=config.DATA_START,
            end_date=config.DATA_END,
            frequency="d",
            adjustflag="2",  # 前复权；指数亦可用
        )
        rows = []
        while rs.error_code == "0" and rs.next():
            rows.append(rs.get_row_data())
        if not rows:
            raise RuntimeError(f"baostock empty: {code} err={rs.error_msg}")
        df = pd.DataFrame(rows, columns=rs.fields)
        return _normalize(df)
    finally:
        bs.logout()


def fetch_stock_akshare(symbol: str) -> pd.DataFrame:
    import akshare as ak

    df = ak.stock_zh_a_hist(
        symbol=symbol,
        period="daily",
        start_date=config.DATA_START.replace("-", ""),
        end_date=config.DATA_END.replace("-", ""),
        adjust="qfq",
    )
    return _normalize(df)


def fetch_index_akshare(symbol: str = "000300") -> pd.DataFrame:
    import akshare as ak

    try:
        df = ak.stock_zh_index_daily(symbol=f"sh{symbol}")
        out = _normalize(df)
        if len(out) > 100:
            return out
    except Exception:
        pass
    df2 = ak.index_zh_a_hist(
        symbol=symbol,
        period="daily",
        start_date=config.DATA_START.replace("-", ""),
        end_date=config.DATA_END.replace("-", ""),
    )
    return _normalize(df2)


def fetch_one(symbol: str, is_index: bool = False) -> pd.DataFrame:
    errors = []
    try:
        df = fetch_baostock(symbol, is_index=is_index)
        if len(df) > 100:
            return df
        errors.append(f"baostock too short ({len(df)})")
    except Exception as e:
        errors.append(f"baostock: {e}")

    try:
        if is_index:
            df = fetch_index_akshare(symbol)
        else:
            df = fetch_stock_akshare(symbol)
        if len(df) > 100:
            return df
        errors.append(f"akshare too short ({len(df)})")
    except Exception as e:
        errors.append(f"akshare: {e}")

    raise RuntimeError(f"{symbol} 拉取失败: {errors}")


def _call_with_timeout(fn, timeout_sec=12, default=None):
    """避免 AkShare 卡死阻塞整条流水线。"""
    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
        fut = ex.submit(fn)
        try:
            return fut.result(timeout=timeout_sec)
        except Exception:
            return default


def build_sentiment_for(symbol: str, price_df: pd.DataFrame) -> pd.DataFrame:
    """用 AkShare 舆情/新闻生成日度 score；不足时用动量代理（可复现）。"""
    dates = pd.to_datetime(price_df["date"])
    close = price_df.set_index(pd.to_datetime(price_df["date"]))["close"].astype(float)
    mom = close.pct_change(5)
    score = mom.rank(pct=True).fillna(0.5).reindex(dates).ffill().fillna(0.5)
    source_note = "momentum_proxy_5d"

    def _try_comment():
        import akshare as ak

        return ak.stock_comment_em()

    def _try_news():
        import akshare as ak

        return ak.stock_news_em(symbol=symbol)

    comment = _call_with_timeout(_try_comment, timeout_sec=15)
    if comment is not None and len(comment) > 0:
        try:
            code_col = next((c for c in comment.columns if "代码" in str(c)), None)
            if code_col is not None:
                row = comment[comment[code_col].astype(str).str.zfill(6) == symbol]
                if not row.empty:
                    score_col = next(
                        (c for c in row.columns if "综合得分" in str(c) or "评分" in str(c)),
                        None,
                    )
                    if score_col is not None:
                        val = float(row.iloc[0][score_col])
                        if val > 10:
                            val = val / 100.0
                        elif val > 1.5:
                            val = val / 5.0
                        val = float(np.clip(val, 0, 1))
                        # 与动量混合，避免单点常数
                        score = (0.5 * score + 0.5 * val).clip(0, 1)
                        source_note = "akshare_comment_em+momentum"
        except Exception:
            pass

    news = _call_with_timeout(_try_news, timeout_sec=15)
    if news is not None and len(news) > 0:
        try:
            date_col = next((c for c in news.columns if "时间" in str(c) or "日期" in str(c)), None)
            title_col = next((c for c in news.columns if "标题" in str(c)), None)
            if date_col and title_col:
                pos_kw = ["增长", "上涨", "盈利", "突破", "看好", "中标", "回购", "超预期", "创新高"]
                neg_kw = ["下跌", "亏损", "风险", "下调", "减持", "处罚", "诉讼", "暴雷", "预警"]
                news = news.copy()
                news["_d"] = pd.to_datetime(news[date_col], errors="coerce").dt.normalize()
                for _, r in news.iterrows():
                    d = r["_d"]
                    if pd.isna(d) or d not in score.index:
                        continue
                    text = str(r[title_col])
                    s = float(score.loc[d]) if d in score.index else 0.5
                    if any(k in text for k in pos_kw):
                        s = min(1.0, s + 0.15)
                    if any(k in text for k in neg_kw):
                        s = max(0.0, s - 0.15)
                    score.loc[d] = s
                score = score.ffill().fillna(0.5)
                source_note = "akshare_news_em+momentum"
        except Exception:
            pass

    out = pd.DataFrame(
        {
            "date": dates.values,
            "score": np.asarray(score.values, dtype=float),
            "source": source_note,
        }
    )
    return out


def main():
    config.DATA_RAW.mkdir(parents=True, exist_ok=True)
    config.DATA_SENTIMENT.mkdir(parents=True, exist_ok=True)

    symbols = list(config.STOCK_POOL) + [config.BENCHMARK]
    ok = 0
    for i, symbol in enumerate(symbols):
        is_index = symbol == config.BENCHMARK
        print(f"[{i+1}/{len(symbols)}] 拉取 {symbol} ...", flush=True)
        try:
            df = fetch_one(symbol, is_index=is_index)
            path = config.DATA_RAW / f"{symbol}.csv"
            df.to_csv(path, index=False)
            print(f"  -> {path.name} rows={len(df)}", flush=True)
            if not is_index:
                # 舆情：先写动量代理，再尝试 AkShare（失败不影响）
                sent = build_sentiment_for(symbol, df)
                sent.to_csv(config.DATA_SENTIMENT / f"{symbol}.csv", index=False)
                print(f"  -> sentiment source={sent['source'].iloc[0]}", flush=True)
            ok += 1
        except Exception as e:
            print(f"  !! 失败: {e}", flush=True)
        time.sleep(0.2)

    if ok < 6:
        raise SystemExit(f"成功拉取不足 6 只（成功 {ok}），请检查网络后重试")

    from backtest.data_quality import make_sample, validate_and_clean_dir

    print("校验与清洗...", flush=True)
    validate_and_clean_dir()
    make_sample()
    print("完成。", flush=True)


if __name__ == "__main__":
    main()
