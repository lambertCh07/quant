"""行情数据校验与清洗。"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd

import config


REQUIRED_COLS = ["date", "open", "high", "low", "close", "volume"]


def _ensure_datetime(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"])
    return out.sort_values("date").reset_index(drop=True)


def validate_one(symbol: str, df: pd.DataFrame) -> Dict[str, Any]:
    issues: List[str] = []
    report: Dict[str, Any] = {"symbol": symbol, "rows": len(df), "issues": issues}

    if df.empty:
        issues.append("空表")
        return report

    missing_cols = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing_cols:
        issues.append(f"缺列: {missing_cols}")
        return report

    d = _ensure_datetime(df)
    # 重复日期
    dup = int(d["date"].duplicated().sum())
    if dup:
        issues.append(f"重复日期 {dup} 条")

    # 缺失值
    na_counts = d[REQUIRED_COLS].isna().sum()
    for col, n in na_counts.items():
        if n > 0:
            issues.append(f"{col} 缺失 {int(n)} 条")

    # OHLC 逻辑
    bad_ohlc = (
        (d["high"] < d["low"])
        | (d["high"] < d["open"])
        | (d["high"] < d["close"])
        | (d["low"] > d["open"])
        | (d["low"] > d["close"])
    )
    n_bad = int(bad_ohlc.sum())
    if n_bad:
        issues.append(f"OHLC逻辑错误 {n_bad} 条")

    # 负价 / 负量
    if (d[["open", "high", "low", "close"]] <= 0).any().any():
        issues.append("存在非正价格")
    if (d["volume"] < 0).any():
        issues.append("存在负成交量")

    # 异常跳空：单日涨跌幅 > 25%（前复权后偶发，记预警）
    ret = d["close"].pct_change().abs()
    jump = int((ret > 0.25).sum())
    if jump:
        issues.append(f"异常跳空(>|25%|) {jump} 次（预警）")

    # 疑似复权断裂：相邻收盘价比值极端
    ratio = d["close"] / d["close"].shift(1)
    break_n = int(((ratio > 1.5) | (ratio < 0.67)).sum())
    if break_n:
        issues.append(f"疑似复权断裂 {break_n} 次（预警）")

    report["date_start"] = str(d["date"].iloc[0].date())
    report["date_end"] = str(d["date"].iloc[-1].date())
    report["n_issues"] = len(issues)
    return report


def clean_one(df: pd.DataFrame) -> pd.DataFrame:
    d = _ensure_datetime(df)
    d = d.drop_duplicates(subset=["date"], keep="last")
    for col in ["open", "high", "low", "close", "volume"]:
        d[col] = pd.to_numeric(d[col], errors="coerce")

    # 剔除关键缺价行
    d = d.dropna(subset=["open", "high", "low", "close"])

    # 修正 OHLC：high=max, low=min
    d["high"] = d[["open", "high", "low", "close"]].max(axis=1)
    d["low"] = d[["open", "high", "low", "close"]].min(axis=1)

    # 成交量缺失填 0（视为停牌）
    d["volume"] = d["volume"].fillna(0).clip(lower=0)

    # 前收：用前一日收盘
    d["pre_close"] = d["close"].shift(1)
    d["pre_close"] = d["pre_close"].fillna(d["open"])

    # 涨跌幅
    d["pct_chg"] = (d["close"] / d["pre_close"] - 1.0) * 100

    # 过滤极端复权断裂日：用前后均值平滑 close，并重算
    ratio = d["close"] / d["close"].shift(1)
    mask = (ratio > 1.5) | (ratio < 0.67)
    if mask.any():
        # 不删除交易日，标记 suspended-like：volume=0 避免交易
        d.loc[mask, "volume"] = 0

    d = d.sort_values("date").reset_index(drop=True)
    return d


def validate_and_clean_dir(
    raw_dir: Path = None,
    clean_dir: Path = None,
) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
    raw_dir = raw_dir or config.DATA_RAW
    clean_dir = clean_dir or config.DATA_CLEAN
    clean_dir.mkdir(parents=True, exist_ok=True)

    reports = []
    for path in sorted(raw_dir.glob("*.csv")):
        symbol = path.stem
        df = pd.read_csv(path)
        rep = validate_one(symbol, df)
        cleaned = clean_one(df)
        # 清洗后再检一次
        rep_after = validate_one(symbol, cleaned)
        rep["issues_after_clean"] = rep_after["issues"]
        cleaned.to_csv(clean_dir / f"{symbol}.csv", index=False)
        reports.append(rep)

    summary = pd.DataFrame(reports)
    report_path = config.ROOT / "data" / "validation_report.csv"
    summary.to_csv(report_path, index=False)

    # markdown 报告
    md_path = config.ROOT / "data" / "validation_report.md"
    lines = ["# 行情数据校验报告", ""]
    for r in reports:
        lines.append(f"## {r['symbol']}")
        lines.append(f"- 行数: {r.get('rows')}")
        lines.append(f"- 区间: {r.get('date_start')} ~ {r.get('date_end')}")
        if r["issues"]:
            lines.append("- 清洗前问题:")
            for i in r["issues"]:
                lines.append(f"  - {i}")
        else:
            lines.append("- 清洗前: 无明显问题")
        after = r.get("issues_after_clean") or []
        if after:
            lines.append("- 清洗后仍存:")
            for i in after:
                lines.append(f"  - {i}")
        else:
            lines.append("- 清洗后: 通过")
        lines.append("")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return summary, reports


def make_sample(
    clean_dir: Path = None,
    sample_dir: Path = None,
    symbols=None,
    start: str = None,
    end: str = None,
) -> None:
    clean_dir = clean_dir or config.DATA_CLEAN
    sample_dir = sample_dir or config.DATA_SAMPLE
    sample_dir.mkdir(parents=True, exist_ok=True)
    symbols = symbols or config.SAMPLE_SYMBOLS
    start = start or config.SAMPLE_START
    end = end or config.SAMPLE_END
    for s in symbols:
        src = clean_dir / f"{s}.csv"
        if not src.exists():
            continue
        df = pd.read_csv(src, parse_dates=["date"])
        part = df[(df["date"] >= start) & (df["date"] <= end)]
        part.to_csv(sample_dir / f"{s}.csv", index=False)


def load_price_panel(
    data_dir: Path,
    symbols: List[str] = None,
    start: str = None,
    end: str = None,
) -> Dict[str, pd.DataFrame]:
    symbols = symbols or config.STOCK_POOL
    out: Dict[str, pd.DataFrame] = {}
    for s in symbols:
        path = data_dir / f"{s}.csv"
        if not path.exists():
            continue
        df = pd.read_csv(path, parse_dates=["date"])
        if start:
            df = df[df["date"] >= pd.Timestamp(start)]
        if end:
            df = df[df["date"] <= pd.Timestamp(end)]
        df = df.set_index("date").sort_index()
        out[s] = df
    return out


def load_benchmark(data_dir: Path = None, start: str = None, end: str = None) -> pd.DataFrame:
    data_dir = data_dir or config.DATA_CLEAN
    path = data_dir / f"{config.BENCHMARK}.csv"
    if not path.exists():
        return pd.DataFrame()
    df = pd.read_csv(path, parse_dates=["date"])
    if start:
        df = df[df["date"] >= pd.Timestamp(start)]
    if end:
        df = df[df["date"] <= pd.Timestamp(end)]
    return df.set_index("date").sort_index()


def load_sentiment(symbol: str) -> pd.Series:
    path = config.DATA_SENTIMENT / f"{symbol}.csv"
    if not path.exists():
        return pd.Series(dtype=float)
    df = pd.read_csv(path, parse_dates=["date"])
    return df.set_index("date")["score"].astype(float).sort_index()
