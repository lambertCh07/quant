"""回测引擎：信号当日收盘计算，次日开盘成交；T+1 / 涨跌停 / 停牌 / 费用。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

import config
from backtest.fees import calc_commission, calc_stamp_tax
from backtest.metrics import compute_metrics
from backtest.rules import can_buy, can_sell


@dataclass
class BacktestResult:
    nav: pd.Series
    trades: List[Dict[str, Any]] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    daily: pd.DataFrame = field(default_factory=pd.DataFrame)
    benchmark_nav: Optional[pd.Series] = None


class BacktestEngine:
    def __init__(
        self,
        initial_cash: float = None,
        max_positions: int = None,
    ):
        self.initial_cash = initial_cash if initial_cash is not None else config.INITIAL_CASH
        self.max_positions = max_positions  # None = 等权覆盖全部有买入信号的标的

    def run(
        self,
        price_data: Dict[str, pd.DataFrame],
        signals: Dict[str, pd.Series],
        start: Optional[str] = None,
        end: Optional[str] = None,
        benchmark: Optional[pd.DataFrame] = None,
    ) -> BacktestResult:
        """
        price_data: {symbol: DataFrame with date index and open/high/low/close/volume/pre_close}
        signals: {symbol: Series aligned to date, 1=want long, 0=flat}
        """
        # 统一交易日历
        all_dates = sorted(
            set().union(*[set(df.index) for df in price_data.values()])
        )
        all_dates = pd.DatetimeIndex(all_dates)
        if start:
            all_dates = all_dates[all_dates >= pd.Timestamp(start)]
        if end:
            all_dates = all_dates[all_dates <= pd.Timestamp(end)]

        symbols = list(price_data.keys())
        cash = float(self.initial_cash)
        # position: symbol -> {shares, cost, buy_date}
        positions: Dict[str, Dict[str, Any]] = {}
        trades: List[Dict[str, Any]] = []
        records = []

        # 信号在当日收盘产生，次日执行 → 用前一日信号
        shifted_signals = {
            s: signals[s].reindex(all_dates).fillna(0).astype(int).shift(1).fillna(0).astype(int)
            for s in symbols
        }

        for dt in all_dates:
            # 先按开盘价尝试执行信号
            target_long = [s for s in symbols if int(shifted_signals[s].loc[dt]) > 0]

            # 卖出：持仓中不在目标且满足 T+1 / 可卖
            to_sell = [s for s in list(positions.keys()) if s not in target_long]
            for s in to_sell:
                df = price_data[s]
                if dt not in df.index:
                    continue
                row = df.loc[dt]
                pos = positions[s]
                if pd.Timestamp(pos["buy_date"]) >= pd.Timestamp(dt):
                    continue  # T+1
                if not can_sell(row, s):
                    continue
                price = float(row["open"])
                if price <= 0 or np.isnan(price):
                    continue
                shares = pos["shares"]
                amount = shares * price
                commission = calc_commission(amount)
                stamp = calc_stamp_tax(amount)
                cash += amount - commission - stamp
                pnl = amount - commission - stamp - pos["cost"]
                trades.append(
                    {
                        "date": dt,
                        "symbol": s,
                        "side": "sell",
                        "price": price,
                        "shares": shares,
                        "amount": amount,
                        "commission": commission,
                        "stamp_tax": stamp,
                        "pnl": pnl,
                    }
                )
                del positions[s]

            # 买入：目标中未持仓
            to_buy = [s for s in target_long if s not in positions]
            if self.max_positions is not None:
                slots = max(0, self.max_positions - len(positions))
                to_buy = to_buy[:slots]

            # 等权分配可用现金
            n_buy = len(to_buy)
            if n_buy > 0 and cash > 1000:
                # 同时考虑已有持仓，总仓位数 = 当前持仓 + 新买
                total_slots = max(len(positions) + n_buy, 1)
                budget_each = cash / n_buy * 0.98  # 留一点现金付费用

                for s in to_buy:
                    df = price_data[s]
                    if dt not in df.index:
                        continue
                    row = df.loc[dt]
                    if not can_buy(row, s):
                        continue
                    price = float(row["open"])
                    if price <= 0 or np.isnan(price):
                        continue
                    # A股 100 股一手
                    shares = int(budget_each / price / 100) * 100
                    if shares < 100:
                        continue
                    amount = shares * price
                    commission = calc_commission(amount)
                    total_cost = amount + commission
                    if total_cost > cash:
                        shares = int((cash - config.COMMISSION_MIN) / price / 100) * 100
                        if shares < 100:
                            continue
                        amount = shares * price
                        commission = calc_commission(amount)
                        total_cost = amount + commission
                    if total_cost > cash:
                        continue
                    cash -= total_cost
                    positions[s] = {
                        "shares": shares,
                        "cost": total_cost,
                        "buy_date": dt,
                    }
                    trades.append(
                        {
                            "date": dt,
                            "symbol": s,
                            "side": "buy",
                            "price": price,
                            "shares": shares,
                            "amount": amount,
                            "commission": commission,
                            "stamp_tax": 0.0,
                        }
                    )

            # 按收盘价估值
            mv = 0.0
            for s, pos in positions.items():
                df = price_data[s]
                if dt in df.index:
                    px = float(df.loc[dt, "close"])
                    if np.isnan(px):
                        px = float(df.loc[dt, "open"])
                else:
                    px = 0.0
                mv += pos["shares"] * px
            equity = cash + mv
            records.append(
                {
                    "date": dt,
                    "cash": cash,
                    "market_value": mv,
                    "equity": equity,
                    "nav": equity / self.initial_cash,
                    "n_positions": len(positions),
                }
            )

        daily = pd.DataFrame(records).set_index("date")
        nav = daily["nav"]

        bench_nav = None
        if benchmark is not None and len(benchmark) > 0:
            b = benchmark.reindex(all_dates).ffill()
            if "close" in b.columns:
                close = b["close"].astype(float)
                first = close.dropna().iloc[0] if close.notna().any() else 1.0
                bench_nav = (close / first).rename("benchmark_nav")

        metrics = compute_metrics(nav, trades, bench_nav)
        return BacktestResult(
            nav=nav,
            trades=trades,
            metrics=metrics,
            daily=daily,
            benchmark_nav=bench_nav,
        )
