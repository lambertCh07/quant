"""绩效指标。"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd


def max_drawdown(nav: pd.Series) -> float:
    if nav.empty:
        return 0.0
    peak = nav.cummax()
    dd = (nav - peak) / peak
    return float(dd.min())


def annualized_return(nav: pd.Series, trading_days: int = 252) -> float:
    if len(nav) < 2:
        return 0.0
    total = float(nav.iloc[-1] / nav.iloc[0])
    years = (len(nav) - 1) / trading_days
    if years <= 0 or total <= 0:
        return 0.0
    return float(total ** (1 / years) - 1)


def sharpe_ratio(nav: pd.Series, risk_free: float = 0.02, trading_days: int = 252) -> float:
    if len(nav) < 3:
        return 0.0
    rets = nav.pct_change().dropna()
    if rets.std() == 0 or np.isnan(rets.std()):
        return 0.0
    excess = rets - risk_free / trading_days
    return float(np.sqrt(trading_days) * excess.mean() / rets.std())


def win_rate(trades: List[Dict[str, Any]]) -> float:
    """按已平仓交易统计胜率。"""
    closed = [t for t in trades if t.get("side") == "sell" and "pnl" in t]
    if not closed:
        # 退化：用买卖配对
        buys = [t for t in trades if t.get("side") == "buy"]
        sells = [t for t in trades if t.get("side") == "sell"]
        n = min(len(buys), len(sells))
        if n == 0:
            return 0.0
        wins = 0
        for i in range(n):
            if sells[i]["price"] > buys[i]["price"]:
                wins += 1
        return wins / n
    wins = sum(1 for t in closed if t.get("pnl", 0) > 0)
    return wins / len(closed)


def compute_metrics(
    nav: pd.Series,
    trades: Optional[List[Dict[str, Any]]] = None,
    benchmark_nav: Optional[pd.Series] = None,
) -> Dict[str, Any]:
    trades = trades or []
    result = {
        "annual_return": annualized_return(nav),
        "max_drawdown": max_drawdown(nav),
        "sharpe": sharpe_ratio(nav),
        "win_rate": win_rate(trades),
        "final_nav": float(nav.iloc[-1]) if len(nav) else 1.0,
        "total_return": float(nav.iloc[-1] / nav.iloc[0] - 1) if len(nav) > 1 else 0.0,
        "n_trades": len([t for t in trades if t.get("side") in ("buy", "sell")]),
    }
    if benchmark_nav is not None and len(benchmark_nav) > 1:
        result["benchmark_annual_return"] = annualized_return(benchmark_nav)
        result["benchmark_total_return"] = float(
            benchmark_nav.iloc[-1] / benchmark_nav.iloc[0] - 1
        )
    return result
