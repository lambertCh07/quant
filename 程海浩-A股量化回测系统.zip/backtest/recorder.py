"""实验记录自动落盘。"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import pandas as pd

import config


def _ensure_dirs():
    config.RECORDS_DIR.mkdir(parents=True, exist_ok=True)


def append_record(record: Dict[str, Any]) -> Path:
    """追加一条实验记录，并刷新对比结果.csv。"""
    _ensure_dirs()
    record = dict(record)
    record.setdefault("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    # 单条 jsonl
    jsonl = config.RECORDS_DIR / "experiments.jsonl"
    with jsonl.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")

    # 汇总 csv
    rows = []
    if jsonl.exists():
        for line in jsonl.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
    df = pd.json_normalize(rows)
    csv_path = config.RECORDS_DIR / "对比结果.csv"
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    # 每条也写独立小文件便于核验
    n = len(rows)
    one = config.RECORDS_DIR / f"exp_{n:04d}.json"
    one.write_text(json.dumps(record, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return csv_path


def record_count() -> int:
    jsonl = config.RECORDS_DIR / "experiments.jsonl"
    if not jsonl.exists():
        return 0
    return sum(1 for line in jsonl.read_text(encoding="utf-8").splitlines() if line.strip())


def flatten_metrics(prefix: str, metrics: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    for k, v in (metrics or {}).items():
        if isinstance(v, (int, float)):
            out[f"{prefix}_{k}"] = round(float(v), 6)
        else:
            out[f"{prefix}_{k}"] = v
    return out
