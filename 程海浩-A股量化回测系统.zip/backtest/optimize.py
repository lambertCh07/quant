"""网格寻优：样本内调参，样本外选优。"""
from __future__ import annotations

import itertools
from typing import Any, Dict, Iterable, List

from backtest.runner import run_is_oos, save_strategy_json
from strategies import get_strategy


def grid_params(strategy_name: str) -> List[Dict[str, Any]]:
    """各策略默认搜索网格（保证总实验数充足）。"""
    if strategy_name == "trend":
        shorts = [3, 5, 8, 10]
        longs = [15, 20, 30, 40, 60]
        grids = [{"short_window": s, "long_window": l} for s, l in itertools.product(shorts, longs) if s < l]
        return grids
    if strategy_name == "mean_reversion":
        windows = [10, 15, 20, 30]
        stds = [1.5, 2.0, 2.5, 3.0]
        return [{"window": w, "num_std": n} for w, n in itertools.product(windows, stds)]
    if strategy_name == "multi_factor":
        grids = []
        for mom in [10, 20, 40]:
            for buy in [0.55, 0.60, 0.65]:
                for sell in [0.35, 0.40, 0.45]:
                    if sell < buy:
                        grids.append(
                            {
                                "mom_window": mom,
                                "vol_window": 20,
                                "ma_window": 60,
                                "buy_threshold": buy,
                                "sell_threshold": sell,
                                "use_sentiment": 1,
                            }
                        )
        return grids
    strategy = get_strategy(strategy_name)
    return [dict(strategy.default_params)]


def score_oos(summary: Dict[str, Any]) -> float:
    """样本外综合得分：夏普优先，回撤惩罚。"""
    sharpe = float(summary.get("oos_sharpe") or 0)
    mdd = abs(float(summary.get("oos_max_drawdown") or 0))
    ret = float(summary.get("oos_annual_return") or 0)
    return sharpe + 0.5 * ret - 1.0 * mdd


def optimize(
    strategy_name: str,
    param_grid: Iterable[Dict[str, Any]] = None,
    data_dir=None,
    symbols=None,
) -> Dict[str, Any]:
    grid = list(param_grid) if param_grid is not None else grid_params(strategy_name)
    best = None
    best_score = float("-inf")
    all_summaries = []

    for i, params in enumerate(grid):
        tag = f"optimize_{strategy_name}_{i+1}"
        print(f"  grid {i+1}/{len(grid)}: {params}")
        out = run_is_oos(
            strategy_name,
            params=params,
            data_dir=data_dir,
            symbols=symbols,
            record=True,
            tag=tag,
        )
        summary = out["summary"]
        all_summaries.append(summary)
        sc = score_oos(summary)
        summary["oos_score"] = sc
        if sc > best_score:
            best_score = sc
            best = summary

    if best is None:
        raise RuntimeError("寻优无结果")
    path = save_strategy_json(best)
    print(f"最优已写入 {path}")
    return {"best": best, "all": all_summaries, "path": path}
