"""统一：加载数据 → 生成信号 → 回测 → 记录。"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

import config
from backtest.data_quality import load_benchmark, load_price_panel, load_sentiment
from backtest.engine import BacktestEngine, BacktestResult
from backtest.recorder import append_record, flatten_metrics
from strategies import get_strategy
from strategies.multi_factor import MultiFactorStrategy


def parse_params(params_str: Optional[str]) -> Dict[str, Any]:
    if not params_str:
        return {}
    out: Dict[str, Any] = {}
    for part in params_str.split(","):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, v = part.split("=", 1)
        k = k.strip()
        v = v.strip()
        try:
            if "." in v:
                out[k] = float(v)
            else:
                out[k] = int(v)
        except ValueError:
            out[k] = v
    return out


def generate_all_signals(
    strategy_name: str,
    price_data: Dict[str, pd.DataFrame],
    params: Dict[str, Any],
) -> Dict[str, pd.Series]:
    strategy = get_strategy(strategy_name)
    signals = {}
    for symbol, df in price_data.items():
        if isinstance(strategy, MultiFactorStrategy):
            sent = load_sentiment(symbol)
            signals[symbol] = strategy.generate_signals(df, params, sentiment=sent)
        else:
            signals[symbol] = strategy.generate_signals(df, params)
    return signals


def run_backtest(
    strategy_name: str,
    params: Optional[Dict[str, Any]] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
    data_dir: Optional[Path] = None,
    symbols: Optional[List[str]] = None,
    record: bool = True,
    tag: str = "",
) -> BacktestResult:
    params = params or {}
    data_dir = data_dir or config.DATA_CLEAN
    price_data = load_price_panel(data_dir, symbols=symbols, start=start, end=end)
    if not price_data:
        raise FileNotFoundError(f"未找到行情数据: {data_dir}")
    bench = load_benchmark(data_dir, start=start, end=end)
    signals = generate_all_signals(strategy_name, price_data, params)
    engine = BacktestEngine()
    result = engine.run(price_data, signals, start=start, end=end, benchmark=bench)

    if record:
        strategy = get_strategy(strategy_name)
        merged = strategy.resolve_params(params)
        rec = {
            "tag": tag,
            "strategy": strategy_name,
            "params": merged,
            "start": start,
            "end": end,
            "symbols": list(price_data.keys()),
            "n_symbols": len(price_data),
            **flatten_metrics("full", result.metrics),
        }
        append_record(rec)
    return result


def run_is_oos(
    strategy_name: str,
    params: Optional[Dict[str, Any]] = None,
    data_dir: Optional[Path] = None,
    symbols: Optional[List[str]] = None,
    record: bool = True,
    tag: str = "",
) -> Dict[str, Any]:
    params = params or {}
    data_dir = data_dir or config.DATA_CLEAN

    is_res = run_backtest(
        strategy_name,
        params,
        start=config.IS_START,
        end=config.IS_END,
        data_dir=data_dir,
        symbols=symbols,
        record=False,
    )
    oos_res = run_backtest(
        strategy_name,
        params,
        start=config.OOS_START,
        end=config.OOS_END,
        data_dir=data_dir,
        symbols=symbols,
        record=False,
    )

    strategy = get_strategy(strategy_name)
    merged = strategy.resolve_params(params)
    summary = {
        "tag": tag,
        "strategy": strategy_name,
        "params": merged,
        "is_start": config.IS_START,
        "is_end": config.IS_END,
        "oos_start": config.OOS_START,
        "oos_end": config.OOS_END,
        "symbols": symbols or list(load_price_panel(data_dir).keys()),
        **flatten_metrics("is", is_res.metrics),
        **flatten_metrics("oos", oos_res.metrics),
    }
    if record:
        append_record(summary)
    return {
        "summary": summary,
        "is": is_res,
        "oos": oos_res,
    }


def save_strategy_json(summary: Dict[str, Any], path: Optional[Path] = None) -> Path:
    path = path or (config.STRATEGY_DIR / "strategy.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "strategy": summary["strategy"],
        "params": summary["params"],
        "sample_in": {
            "start": summary.get("is_start"),
            "end": summary.get("is_end"),
            "annual_return": summary.get("is_annual_return"),
            "max_drawdown": summary.get("is_max_drawdown"),
            "sharpe": summary.get("is_sharpe"),
            "win_rate": summary.get("is_win_rate"),
            "total_return": summary.get("is_total_return"),
        },
        "sample_out": {
            "start": summary.get("oos_start"),
            "end": summary.get("oos_end"),
            "annual_return": summary.get("oos_annual_return"),
            "max_drawdown": summary.get("oos_max_drawdown"),
            "sharpe": summary.get("oos_sharpe"),
            "win_rate": summary.get("oos_win_rate"),
            "total_return": summary.get("oos_total_return"),
        },
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
