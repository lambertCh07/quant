"""交易成本。"""
from __future__ import annotations

import config


def calc_commission(amount: float) -> float:
    """佣金万分之 2.5，最低 5 元。"""
    fee = abs(amount) * config.COMMISSION_RATE
    return max(fee, config.COMMISSION_MIN) if abs(amount) > 0 else 0.0


def calc_stamp_tax(sell_amount: float) -> float:
    """卖出印花税万分之 5。"""
    if sell_amount <= 0:
        return 0.0
    return sell_amount * config.STAMP_TAX_RATE
