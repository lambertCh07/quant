"""涨跌停 / 停牌判定。"""
from __future__ import annotations

import config


def limit_pct_for(symbol: str) -> float:
    """按代码粗分涨跌停幅度。"""
    if symbol.startswith(("300", "301", "688", "689")):
        return config.LIMIT_PCT_GEM
    return config.LIMIT_PCT_MAIN


def is_suspended(row) -> bool:
    vol = float(row.get("volume", 0) or 0)
    return vol <= 0


def is_limit_up(row, symbol: str) -> bool:
    """相对昨收涨幅接近涨停。"""
    pre = row.get("pre_close")
    close = row.get("close")
    open_ = row.get("open")
    if pre is None or pre <= 0:
        return False
    pct = limit_pct_for(symbol)
    # 开盘即涨停：open 接近涨停价
    limit_price = float(pre) * (1 + pct)
    if open_ is not None and float(open_) >= limit_price * 0.999:
        return True
    if close is not None and float(close) >= limit_price * 0.999:
        # 收盘涨停当日通常难买入；撮合用次日开盘，次日若开盘涨停则不成交
        return False
    return False


def is_limit_down(row, symbol: str) -> bool:
    pre = row.get("pre_close")
    open_ = row.get("open")
    if pre is None or pre <= 0:
        return False
    pct = limit_pct_for(symbol)
    limit_price = float(pre) * (1 - pct)
    if open_ is not None and float(open_) <= limit_price * 1.001:
        return True
    return False


def can_buy(row, symbol: str) -> bool:
    if is_suspended(row):
        return False
    if is_limit_up(row, symbol):
        return False
    return True


def can_sell(row, symbol: str) -> bool:
    if is_suspended(row):
        return False
    if is_limit_down(row, symbol):
        return False
    return True
