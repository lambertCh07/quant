"""全局配置：股票池、费率、时段切分等（不得更改撮合与费率规则）。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# 固定股票池（不得更改）
STOCK_POOL = [
    "600519",  # 贵州茅台
    "601318",  # 中国平安
    "601398",  # 工商银行
    "600900",  # 长江电力
    "000002",  # 万科A
    "600276",  # 恒瑞医药
    "002415",  # 海康威视
    "002594",  # 比亚迪
    "600111",  # 北方稀土
    "601888",  # 中国中免
]

STOCK_NAMES = {
    "600519": "贵州茅台",
    "601318": "中国平安",
    "601398": "工商银行",
    "600900": "长江电力",
    "000002": "万科A",
    "600276": "恒瑞医药",
    "002415": "海康威视",
    "002594": "比亚迪",
    "600111": "北方稀土",
    "601888": "中国中免",
}

BENCHMARK = "000300"  # 沪深300

DATA_START = "2019-01-01"
DATA_END = "2024-12-31"

# 样本内 / 样本外
IS_START = "2019-01-01"
IS_END = "2022-12-31"
OOS_START = "2023-01-01"
OOS_END = "2024-12-31"

# 初始资金
INITIAL_CASH = 1_000_000.0

# 费率：佣金万分之 2.5（最低 5 元）；卖出印花税万分之 5
COMMISSION_RATE = 0.00025
COMMISSION_MIN = 5.0
STAMP_TAX_RATE = 0.0005

# 涨跌停阈值（按代码前缀粗分）
# 主板约 ±10%，创业板/科创板约 ±20%
LIMIT_PCT_MAIN = 0.098  # 略小于 10% 避免浮点误差
LIMIT_PCT_GEM = 0.198

# 路径
DATA_RAW = ROOT / "data" / "raw"
DATA_CLEAN = ROOT / "data" / "clean"
DATA_SAMPLE = ROOT / "data" / "sample"
DATA_SENTIMENT = ROOT / "data" / "sentiment"
STRATEGY_DIR = ROOT / "strategy"
RECORDS_DIR = ROOT / "records"
STATIC_PLOTS = ROOT / "static" / "plots"

SAMPLE_SYMBOLS = ["600519", "601318", "000002"]
SAMPLE_START = "2023-01-01"
SAMPLE_END = "2023-03-31"
