#!/usr/bin/env python3
"""命令行入口：run / optimize / report / fetch / clean。"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import config
from backtest.optimize import optimize
from backtest.runner import parse_params, run_backtest, run_is_oos, save_strategy_json


def cmd_fetch(_args):
    from scripts.fetch_data import main as fetch_main

    fetch_main()


def cmd_clean(_args):
    from backtest.data_quality import make_sample, validate_and_clean_dir

    validate_and_clean_dir()
    make_sample()
    print("清洗完成，报告见 data/validation_report.md")


def cmd_run(args):
    params = parse_params(args.params)
    data_dir = Path(args.data_dir) if args.data_dir else config.DATA_CLEAN
    symbols = args.symbols.split(",") if args.symbols else None
    if args.is_oos:
        out = run_is_oos(
            args.strategy,
            params=params,
            data_dir=data_dir,
            symbols=symbols,
            record=True,
            tag=args.tag or "run_is_oos",
        )
        print(json.dumps(out["summary"], ensure_ascii=False, indent=2, default=str))
        if args.save_best:
            save_strategy_json(out["summary"])
    else:
        result = run_backtest(
            args.strategy,
            params=params,
            start=args.start,
            end=args.end,
            data_dir=data_dir,
            symbols=symbols,
            record=True,
            tag=args.tag or "run",
        )
        print(json.dumps(result.metrics, ensure_ascii=False, indent=2, default=str))


def cmd_optimize(args):
    data_dir = Path(args.data_dir) if args.data_dir else config.DATA_CLEAN
    symbols = args.symbols.split(",") if args.symbols else None
    strategies = [args.strategy] if args.strategy != "all" else ["trend", "mean_reversion", "multi_factor"]
    best_overall = None
    best_score = float("-inf")
    for name in strategies:
        print(f"=== 寻优 {name} ===")
        out = optimize(name, data_dir=data_dir, symbols=symbols)
        sc = out["best"].get("oos_score", 0)
        if sc > best_score:
            best_score = sc
            best_overall = out["best"]
    if best_overall is not None:
        path = save_strategy_json(best_overall)
        print(f"全局最优: {best_overall['strategy']} -> {path}")
        print(json.dumps(best_overall, ensure_ascii=False, indent=2, default=str))


def cmd_report(args):
    from app import create_app

    app = create_app()
    print(f"报告页: http://127.0.0.1:{args.port}/")
    app.run(host="127.0.0.1", port=args.port, debug=False)


def build_parser():
    p = argparse.ArgumentParser(description="A股量化回测系统")
    sub = p.add_subparsers(dest="command", required=True)

    f = sub.add_parser("fetch", help="拉取行情与舆情")
    f.set_defaults(func=cmd_fetch)

    c = sub.add_parser("clean", help="校验清洗")
    c.set_defaults(func=cmd_clean)

    r = sub.add_parser("run", help="运行回测")
    r.add_argument("--strategy", required=True, choices=["trend", "mean_reversion", "multi_factor"])
    r.add_argument("--params", default="", help="如 short=5,long=20")
    r.add_argument("--start", default=config.DATA_START)
    r.add_argument("--end", default=config.DATA_END)
    r.add_argument("--data-dir", default="")
    r.add_argument("--symbols", default="", help="逗号分隔，默认全部股票池")
    r.add_argument("--is-oos", action="store_true", help="样本内外分别回测")
    r.add_argument("--save-best", action="store_true")
    r.add_argument("--tag", default="")
    r.set_defaults(func=cmd_run)

    o = sub.add_parser("optimize", help="网格寻优")
    o.add_argument("--strategy", default="all", help="trend/mean_reversion/multi_factor/all")
    o.add_argument("--data-dir", default="")
    o.add_argument("--symbols", default="")
    o.set_defaults(func=cmd_optimize)

    rp = sub.add_parser("report", help="启动 Flask 报告页")
    rp.add_argument("--port", type=int, default=5000)
    rp.set_defaults(func=cmd_report)

    return p


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
