# A股量化回测系统

固定十只股票池 · 趋势跟踪 / 均值回复 / 多因子 · 样本内外寻优 · Flask 报告页

## 环境

```bash
conda create -n quant python=3.10 -y
conda activate quant
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
python -c "import akshare, pandas, matplotlib, flask; print('环境 OK')"
```

## 三条命令复现

```bash
# 1) 已附带清洗数据时可跳过；否则重新拉取
python scripts/fetch_data.py

# 2) 运行最优策略回测（或网格寻优）
python cli.py run --strategy trend --params short_window=5,long_window=20 --is-oos
# 或：python cli.py optimize --strategy all

# 3) 打开绩效报告页
python app.py
```

Windows 也可双击 `启动.bat` 打开报告页（需已激活 `quant` 环境）。

浏览器访问：http://127.0.0.1:5000/

## 目录说明

- `data/` 原始、清洗、样例行情与舆情 CSV + 校验报告
- `strategies/` 三种策略实现
- `backtest/` 引擎、费用、规则、绩效、寻优、实验记录
- `strategy/strategy.json` 自研最优配置
- `records/` 实验记录与对比结果（系统自动导出）

## 撮合规则（不可更改）

信号当日收盘计算，次日开盘成交；T+1；涨跌停不成交；停牌不可交易；佣金万分之 2.5（最低 5 元）；卖出印花税万分之 5；初始资金 100 万元。
