@echo off
chcp 65001 >nul
cd /d %~dp0
echo ===== A股量化回测系统 =====
echo [1] 激活环境并启动报告页
call conda activate quant 2>nul
python -c "import akshare,pandas,matplotlib,flask; print('环境 OK')" || (
  echo 请先按 README 创建 conda 环境 quant 并安装依赖
  pause
  exit /b 1
)
echo 打开浏览器访问 http://127.0.0.1:5000/
python app.py
pause
