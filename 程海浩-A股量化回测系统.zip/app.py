#!/usr/bin/env python3
"""Flask 绩效报告页。"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from flask import Flask, render_template, send_from_directory

import config
from backtest.runner import run_backtest, run_is_oos

# 中文字体
plt.rcParams["font.sans-serif"] = ["Arial Unicode MS", "PingFang SC", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def _load_strategy_cfg():
    path = config.STRATEGY_DIR / "strategy.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {
        "strategy": "trend",
        "params": {"short_window": 5, "long_window": 20},
        "sample_in": {},
        "sample_out": {},
    }


def _plot_nav(result, out_path: Path, title: str):
    config.STATIC_PLOTS.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.plot(result.nav.index, result.nav.values, label="策略净值", linewidth=1.5)
    if result.benchmark_nav is not None:
        b = result.benchmark_nav.dropna()
        ax.plot(b.index, b.values, label="沪深300", linewidth=1.2, alpha=0.85)
    ax.set_title(title)
    ax.set_xlabel("日期")
    ax.set_ylabel("净值")
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=120)
    plt.close(fig)


def create_app() -> Flask:
    app = Flask(__name__)

    @app.route("/")
    def index():
        cfg = _load_strategy_cfg()
        strategy = cfg.get("strategy", "trend")
        params = cfg.get("params") or {}

        # 全区间回测用于画图
        full = run_backtest(
            strategy,
            params=params,
            start=config.DATA_START,
            end=config.DATA_END,
            record=False,
            tag="report_full",
        )
        _plot_nav(full, config.STATIC_PLOTS / "nav_full.png", f"{strategy} 全区间净值")

        is_oos = run_is_oos(strategy, params=params, record=False, tag="report_is_oos")
        _plot_nav(is_oos["oos"], config.STATIC_PLOTS / "nav_oos.png", f"{strategy} 样本外净值")

        # 实验记录摘要
        cmp_path = config.RECORDS_DIR / "对比结果.csv"
        n_records = 0
        top_rows = []
        if cmp_path.exists():
            df = pd.read_csv(cmp_path)
            n_records = len(df)
            cols = [c for c in df.columns if c in (
                "strategy", "tag", "oos_sharpe", "oos_annual_return", "oos_max_drawdown",
                "is_sharpe", "params",
            ) or c.startswith("params")]
            show = df.tail(10)
            top_rows = show.to_dict(orient="records")

        return render_template(
            "report.html",
            cfg=cfg,
            full_metrics=full.metrics,
            is_metrics=is_oos["is"].metrics,
            oos_metrics=is_oos["oos"].metrics,
            n_records=n_records,
            top_rows=top_rows,
        )

    @app.route("/static/plots/<path:filename>")
    def plots(filename):
        return send_from_directory(config.STATIC_PLOTS, filename)

    return app


def main():
    app = create_app()
    print("报告页: http://127.0.0.1:5000/")
    app.run(host="127.0.0.1", port=5000, debug=False)


if __name__ == "__main__":
    main()
